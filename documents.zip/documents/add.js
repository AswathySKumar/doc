function addfunction(){
    var num1=10;
    var num2=20;
    var result=num1+num2;
    alert(result);

}
